function getSumNum(a, b) {
    const customPromise = new Promise((resolve, reject) => {
      const sum = a + b;
  
      if(sum <= 5){
        resolve("Let's go for the next step")
      } else {
        reject('Please check the value once')
      }
    })
  
    return customPromise
  }
  // consuming the promise
getSumNum(1, 1).then(data => {
    console.log(data)
  })
  .catch(err => {
    console.log(err)
  })