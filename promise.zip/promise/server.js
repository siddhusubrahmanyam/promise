const express = require('express');
const path = require('path');
var http = require('http');
var fs = require('fs');
const app = express();
app.use(express.static(path.join(__dirname, 'public')));
    app.get('/', async(req, res) => {
        fs.readFile('result.html',  (err, result) => {
        res.writeHead(200, {'Content-Type':'text/html'});
        res.write(result);
        return res.end();
        }); 
        });
    app.get('/stockdetails', async(req, res) => {
    
    res.sendFile(path.join(__dirname, 'public', 'CanvasJS-Spline-Stockchart.html')); 
    });
    app.get('/data', async(req, res) => {
        res.sendFile(path.join(__dirname, 'public', 'fetch.html')); 
        });



 app.listen(2500, function (req, res) {
    console.log('Server is running on 2500');
});