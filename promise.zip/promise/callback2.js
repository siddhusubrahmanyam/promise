dboper.insertDocument(db, { name: "Test", description: "Test"},
	"test", (result) => {
		console.log("Insert Document:\n", result.ops);

		dboper.findDocuments(db, "test", (docs) => {
			console.log("Found Documents:\n", docs);

			dboper.updateDocument(db, { name: "Test" },
				{ description: "Updated Test" }, "test",
				(result) => {
					console.log("Updated Document:\n", result.result);

					dboper.findDocuments(db, "test", (docs) => {
						console.log("Found Updated Documents:\n", docs);
							
						db.dropCollection("test", (result) => {
							console.log("Dropped Collection: ", result);

							client.close();
						});
					});
				});
		});
	});
