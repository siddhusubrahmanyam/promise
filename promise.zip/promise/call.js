setTimeout(function (){
    console.log("Meet The Team");
},5000);
console.log("Welcome to SYrahealth");
console.log("Onboarded!!!!!!");