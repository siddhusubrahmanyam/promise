const fs = require('fs');
const data = fs.readFile('data.html', 'utf-8', (err, result) => {
   if(err){
    console.log('Access failed');
   }
   else{
    console.log(result);
   }
})


const data4 = fs.readFile('results.html', 'utf-8', (err4, res4) => {
    if(err4){
        console.log('error res');
    }
    else{
        console.log(res4);
    }
});

const data2 = fs.readFile('result.html', 'utf-8', function (err1, result1){
    if(err1){
        console.log('error page');
    }
    else{
        console.log(result1);
    }
});

var data3 = fs.readFileSync('data.html');
console.log(data3.toString());
console.log("This is the while loop");
let i=1;
while(i<=5) {
    console.log("number is" + i);
    i++;
}

