const EventEmitter = require('events');
const eventEmitter = new EventEmitter();
eventEmitter.on('newListener', (event, listener) => {
    console.log(`the listener is added to ${event}`);
});
eventEmitter.on('removeListener', (event, listener) =>{
    console.log(`the listener is added to ${event}`);
});
const fun1 = (msg) =>{
    console.log("message from func1" + msg);
};
const fun2 = (msg) => {
    console.log("message from func2" + msg);
};
eventEmitter.on('myEvent', fun1);
eventEmitter.on('myEvent', fun2);
//eventEmitter.off('myEvent', fun1);
//eventEmitter.off('myEvent', fun2);
eventEmitter.emit('myEvent', 'event occured');