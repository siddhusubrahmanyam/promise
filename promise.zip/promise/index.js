require('dotenv').config();
const { createAgent } = require('@forestadmin/agent');
createAgent({
    authSecret: process.env.FOREST_AUTH_SECRET,
    envSecret: process.env.FOREST_ENV_SECRET,
    isProduction: process.env.NODE_ENV === 'production',
})
.mountOnStandaloneServer(2500)
.start();