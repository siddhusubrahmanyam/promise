const fs = require("fs");
const filedata = fs.readFileSync('include.txt');
const filedata2 = fs.readFileSync('data.html');
console.log(filedata.toString());
console.log(filedata2.toString());
console.log("Thank you for using node JS");