<script>
  
function yFinance_new(symbol) {
  const url = 'https://query2.finance.yahoo.com/v10/finance/quoteSummary/' + encodeURI(symbol)
    + '?modules=price,assetProfile,summaryDetail,incomeStatementHistory,'
    + 'balanceSheetHistory,defaultKeyStatistics,financialData,calendarEvents,'
    + 'recommendationTrend,upgradeDowngradeHistory,majorHoldersBreakdown'
    ;
  const response = UrlFetchApp.fetch(url, { muteHttpExceptions: true });
  const responseCode = response.getResponseCode();
  if (responseCode === 200) {
    const quote = JSON.parse(response.getContentText());
    return [[
      quote.quoteSummary.result[0].summaryDetail.dividendRate.raw,
      quote.quoteSummary.result[0].summaryDetail.payoutRatio.raw
    ]];
  }
  else {
    return -1;
  }
}

</script>