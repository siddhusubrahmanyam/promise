function onRequest(request, response, modules) {
    modules.request.get('http://www.somedomain.com', function(err, result) {
      modules.logger.info("Request finished");
  });
    modules.logger.info("Continuing code execution");
    return response.complete();
  }