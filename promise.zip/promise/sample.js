var http = require('http');
// http.createServer(function(req, res){
//     res.write('Welcome to syrahealth');
//     res.end();
// }).listen(2000);

// http.createServer(function(req, res){
//     res.writeHead(200, {'Content-Type' :'text/html'});
//     res.write(req.url);
//     res.end();
// }).listen(2000)

function onRequest(request, response, modules){
    modules.request.get('http://www.somegomain.com', function(err, result){
        modules.logger.info("request finished");
    });
    modules.logger.info("continue the code executuon");
    return response.complete();
}