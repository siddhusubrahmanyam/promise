var logger = modules.logger;
logger.info('Started BL processing', function(err, result) {
    if (!request.body.name) {
      logger.fatal('Request did not include a name...');
      response.complete(400);
    }
});